---
name: lead-hunter-builder
description: "Build a personalized lead hunting Google Sheet for a business, freelancer or team. Use when someone wants a lead tracker, cold prospect list, company discovery, professional-contact research, fit scoring, priorities, budgets and recurring searches, or wants to adapt that workflow to an existing sheet. Interviews beginners, generates a configurable Apps Script starter, and guides setup and validation. Not for merely writing outreach, buying lead lists or sending messages."
metadata:
  version: "1.4.0"
---

# Lead Hunter Builder

Assess whether a prospecting sheet fits the business, then build the appropriate demand, cold or mixed workflow. The starter carries the durable queues, stable lead IDs, scoped cell filling and progress reporting from Lead Hunter; its business criteria are configurable. It is a starting implementation, not a promise that every business or scraper works unchanged.

## Own guided completion

Treat a request to build Lead Hunter as authorization to guide the installation through a usable first result. Do not stop after generating files. Complete the profile, choose a suitable acquisition route, generate and test the project, help create or safely adapt the Google Sheet, run native no-spend checks, import one representative lead or run an explicitly approved bounded live pilot, review the resulting row with the owner, and hand over everyday controls. If direct Google access is unavailable, prepare every artifact and guide the remaining clicks one at a time without claiming they were completed.

The normal completion state is a working sheet with its first reviewable lead, tested rules, sources disabled or deliberately enabled, explicit budgets, no unexplained progress state, and a short owner handover. A generated ZIP or Apps Script file alone is incomplete.

## Start with the person

Read [intake.md](references/intake.md). Reuse answers already supplied. In the first response ask at most three short questions: what they sell, who they want to reach, and what a useful opportunity looks like. Accept a website or plain-language answer. Offer examples relevant to their business, not an account-setup questionnaire. Explain unfamiliar terms only when they matter. Continue gathering details in small rounds; summarize inferred choices for correction.

Do not ask for API keys, passwords or billing details in chat. The user enters their own credentials directly in their own Apps Script project. Never put credentials in profiles, code, sheets, screenshots, GitHub or logs. Each installation uses the user's own Google and provider accounts.

## Choose the acquisition method

Read [cold-prospecting.md](references/cold-prospecting.md) before promising a design. Assess how buyers are identifiable, what facts distinguish a suitable customer, how the buying process works and whether research costs suit the deal value. Recommend demand, cold, mixed or limited fit, explaining the gaps. A lack of public buying requests does not disqualify a business. A database match does not establish a need. In cold/mixed builds use structural fit criteria and keep unsupported readiness Unknown. Record the recommendation and limitations in `prospecting`; the cold profile example provides its schema.

For freelancers, agencies and other service sellers, test an explicit service-request source first when it has suitable demand. Upwork through a reviewed Apify actor is the default first candidate: collect a small bounded sample, preserve the complete brief, deduplicate by stable post identity, check applicant eligibility, then let Jev judge the buyer/request, business clue, service fit, readiness and supported next action. Extract or research a company name only from complete source evidence. Confirm the official website before contact research. Find a relevant current decision-maker from the source author/job poster, an official team page, a public professional profile or an allowed people-search endpoint; then use public work-email evidence, Hunter or Apollo within separate capabilities and caps. Hunter can find or verify work email but does not replace people search. Apollo is used only when the owner's key can access the required endpoint. Discovery never submits a proposal or sends outreach.

Add another marketplace, RFP board, community or social-request platform through the same pipeline only after a source-specific pilot. Each adapter must preserve the full request, stable platform ID, public URL, actual posting date, buyer clues, applicant restrictions, budget and competition fields when the provider supplies them. It must fail visibly on schema drift and pass deduplication, eligibility and malformed-record tests. Do not create a second one-off workflow for each platform.

## Design around buying evidence

Read [sources.md](references/sources.md) when selecting sources. Separate an explicit request for help, a timing signal, and a directory prospect. A job listing does not prove openness to an agency; an active advertisement does not prove the advertiser needs new creatives. Recommend one or two sources with a small pilot, not every connector available. Check current official provider docs, actor input/output and pricing before recommending or enabling paid automation. Manual CSV import is a useful complete first stage when accounts or budget are missing.

Define a small set of observable, business-specific fit and readiness criteria. Explain each criterion, exclusion and weight. Target/client geography and provider/applicant geography are separate rules. Company size, pay floors and age limits are optional owner choices. Never import the original agency's DTC, Meta, recruiter or company-name rules as universal defaults. Treat unknown evidence as unknown; finite business-role categories can accept new names without accumulating a blacklist. Hiring intent remains unknown when the source does not explicitly support it, including for a well-matched company. An Upwork row with missing applicant-country evidence cannot become proposal-ready; record a live owner review or capture a supported structured actor field first.

For demand leads, use priority = 45% fit + 30% readiness + 25% freshness as a starting point. Freshness halves every seven days; only a supported opportunity posting date earns it. Directory records and undated or future-dated posts get no freshness bonus. Tune to the user's sales cycle. These are ranking scores, not probabilities of closing. Applicants/proposals may adjust priority only if the source reliably supplies them and the owner agrees; the bundled starter does not implement that adjustment. Cold priority separately combines fit, confirmed contactability and an evidenced timing signal; use its configurable weights and never substitute a collection date for demand.

## Build the reviewable product

Include essential company, opportunity, source, website, fit, status, action and evidence fields automatically. Do not ask beginners to invent the basic schema. Read [fields.md](references/fields.md), then ask only which service-specific details would help them qualify a customer or decide the next action; offer two or three relevant examples and allow none. Keep operational source text, dates, IDs and lookup state hidden. Optional fields are owner-entered; automatic extraction requires an explicit adapter and tests.

Read [architecture.md](references/architecture.md) and [setup-and-testing.md](references/setup-and-testing.md) before building. Record the agreed decisions and open assumptions in `business-profile.json`, following [profile.example.json](assets/profile.example.json). Keep provider prices and model IDs explicit. Never insert keys. Use the bundled generator; run commands yourself if the environment supports execution:

```sh
python3 scripts/build.py --profile /path/to/business-profile.json --out /path/to/lead-hunter-build
python3 scripts/test_builder.py
node scripts/test_engine.mjs /path/to/lead-hunter-build/Code.gs
node scripts/test_contacts.mjs /path/to/lead-hunter-build
```

Resolve relative paths against this skill folder. The generator works offline and creates `Code.gs`, `appsscript.json`, import templates, a field guide and an owner runbook. It does not create a spreadsheet, connect accounts, spend money or install schedules. Default to a new blank sheet. For an existing workbook, first make a copy and inspect its schema; preserve unrelated tabs, human edits and outreach statuses. Required headers map to their physical columns, so whole-column moves and added owner fields can be preserved; missing or duplicated required headers stop writes. Do not run layout migrations against an unfamiliar schema.

Adapt unsupported sources as explicit new adapters with sample output and tests, rather than treating a generic JSON row as valid lead evidence. Build custom criteria through configuration; edit shared mechanics only when the user's requirement genuinely needs it. Keep changes and checks with that generated project.

## Find professional contacts

For contact enrichment read [contact-providers.md](references/contact-providers.md). In assisted mode the engine performs bounded zero-credit checks on official public pages, then tries Apollo People Search only when the owner connected Apollo and that key can use the endpoint. Manual mode uses owner review. It remembers completed checks and plan denial; partial public checks retry within a three-attempt bound, then park for review. Website, company or captured-source changes and thirty-day expiry invalidate identity and public receipts. Supplied domains require a fresh durable identity check before contact research; in assisted mode Fill selected cells adds the required website dependency, while manual mode uses owner review. Hunter can discover named work contacts, find a known person's work email and verify it; Apollo can reveal a selected candidate's work email or phone when supported. Every paid action remains selected-only with a separate explicit credit cap and confirmation. Public pages and actual LinkedIn profiles support identity; a provider's valid mailbox result does not prove current employment or need. Keep source, identity review, mailbox status and verification date distinct. Contacts marked suppressed or rejected stop further enrichment. Unknown/catch-all results remain unavailable for verified outreach. Do not infer private email addresses or present generated patterns as found contacts.

Public email extraction uses each official page separately. Accept visible official-domain contacts or explicitly labeled business-purpose free mailboxes, with the page URL and source context saved in cell notes. Scripts, hidden content, forms, examples and testimonials are not contact evidence. HR/jobs mailboxes require a jobs goal or configured hiring roles; privacy/legal mailboxes require corresponding configured roles. A published candidate does not establish delivery, person ownership, current role or buying intent. Preserve existing owner values and notes; review historical populated contacts rather than assuming a rebuild revalidated them.

Hunter’s local cap uses conservative reservations before requests. Only a validated exact-domain raw empty Domain Search response settles its own new reservation to zero; prior spend and uncertain requests remain counted. Completed redacted receipts archive into the Log with exact readback before leaving the recent ledger. Preserve all unresolved receipts and owner values/formulas/notes. Restore damaged Log headers or conflicting archive data from the workbook copy; reconcile uncertain calls against the provider account. Never reset historical counters or erase receipts to bypass a cap.

Choose the cheapest adequate path: qualify companies first, let the worker inspect public business sources, reuse fresh results, then use a bounded provider lookup. Hunter and Apollo are implemented adapters; Prospeo and Snov remain researched alternatives. `[Working]` is internal automatic work. `[Next]` must name only the remaining owner action or paid tool and its maximum credit cost. Test prerequisites and endpoint access before recommending a tool. Recommend another provider only when a segment pilot shows worthwhile additional coverage. Explain remaining identity review and unsupported integrations; do not imply fully autonomous contact verification.

Preserve the complete captured source up to the documented cell limit, flag larger or known historical truncations, and resume identity scans from their saved cursor. A negative result is valid only after all saved source windows were checked. A discovered company requires the complete name at full-word boundaries and a source quote connecting it to the hiring or buying request. Headings, authors, tools and examples are insufficient. Ambiguous relationships need an exact reviewed quote. Split names continue in the overlapping window; cached found names recheck the exact quoted occurrence and source position, including older receipts. Missing reader connections, unreadable websites, blocked contact pages and deadlines remain incomplete/error states. Do not remove a supplied website merely because its verification failed. An unverified source hint cannot authorize scraping contacts from that site. Supplied and discovered sites use the same identity policy: a readable homepage and clear Jev result, or an exact independent website choice above the existing Jev floor. A fallback reply can select only the supplied host; malformed or unavailable judgments remain incomplete.

## Connect and prove it

Use a Sheets connector when available, otherwise guide Apps Script setup one step at a time. Do not make the beginner operate a terminal if you can generate the files for them. Check actual tool access before promising direct installation. An assistant without code execution can explain setup, but must not claim it generated or tested runnable files.

Use the testing gates in the setup reference: offline fixtures, native no-spend checks, then a small owner-approved live pilot. Show the proposed sources, counts, estimated charge, provider cap and monthly budget before paid work. Keep schedules off until the pilot is reviewed and the owner explicitly chooses the days, hour and timezone. Apps Script owns the schedule; Apify receives individual requests.

Finish with a short plain-language handover: where to work, how to find/import leads, what progress means, how to fill selected cells, edit budgets/schedules and stop automation. Report tests actually run, unresolved integrations and recurring cost assumptions. Never call it fully tested based solely on offline mocks. No automatic emails, proposals, messages or ad launches; outreach drafting is a separate optional workflow.

## Return visits

Read the saved profile and actual sheet/log state before asking the interview again. Compare source yield and accepted leads first; use replies and meetings only when the owner records them. Suggest measured changes rather than growing an unlimited tag list or widening every search. An existing authorization remains valid within its stated scope; a new source, higher cap or expanded schedule needs the owner's decision.
